import React from "react";

const Tab = ({ children }) => {
  return <div>{children}</div>;
};

export default Tab;
