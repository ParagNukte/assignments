export const horizontalScrollItems = [
  {
    id: 1,
    imageSrc: "/card-images/pexels-max-vakhtbovych-6782342.png",
    description: "Modern Wall Decor Framed Painting",
    price: "$199.99",
    rating: 5,
  },
  {
    id: 2,
    imageSrc: "/card-images/Image 40.png",
    description: "Modern Wall Decor Framed Painting",
    price: "$199.99",
    rating: 5,
  },
  {
    id: 3,
    imageSrc: "/card-images/Image 39.png",
    description: "Modern Wall Decor Framed Painting",
    price: "$199.99",
    rating: 5,
  },
  {
    id: 4,
    imageSrc: "/card-images/pexels-pixabay-164455.png",
    description: "Modern Wall Decor Framed Painting",
    price: "$199.99",
    rating: 5,
  },
  // Add more items as needed
];
